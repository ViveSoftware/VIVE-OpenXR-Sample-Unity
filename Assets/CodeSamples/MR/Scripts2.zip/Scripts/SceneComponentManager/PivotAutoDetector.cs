﻿using UnityEngine;

public abstract class PivotAutoDetector : MonoBehaviour
{
    public abstract void GeneratePivot(string pivotName);
}
