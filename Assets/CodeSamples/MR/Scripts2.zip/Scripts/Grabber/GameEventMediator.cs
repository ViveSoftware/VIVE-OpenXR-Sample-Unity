﻿using System;
using UnityEngine;

public static class GameEventMediator
{
    public static Action<GameObject> OnFishFoodAppearHandler = delegate { };
}
