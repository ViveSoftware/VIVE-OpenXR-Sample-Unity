using System;

public static class EventMediator
{
    public static Action LeaveSetupMode;
    public static Action RestartGame;
}
